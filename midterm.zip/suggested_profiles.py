import tkinter as tk
from tkinter import messagebox
import json

# Load existing user details and login credentials from JSON files
try:
    with open("user_details.json", "r") as user_details_file:
        user_details = json.load(user_details_file)
except FileNotFoundError:
    user_details = {}

try:
    with open("login_credentials.json", "r") as login_credentials_file:
        login_credentials = json.load(login_credentials_file)
except FileNotFoundError:
    login_credentials = {}

def display_users_with_same_interest(subject):
    matching_users = {user: details for user, details in user_details.items() if details["interests"] == subject}
    return matching_users

def get_subject_of_interest():
    subject = subject_entry.get().strip()
    matching_users = display_users_with_same_interest(subject)
    result_text.set("\n".join([f"{user}: {details}" for user, details in matching_users.items()]))

# Create the main window
root = tk.Tk()
root.geometry("500x500")
root.title("User Search")

# Create and place the widgets
subject_label = tk.Label(root, text="Enter Subject of Interest:")
subject_label.pack()

subject_entry = tk.Entry(root)
subject_entry.pack()

search_button = tk.Button(root, text="Search", command=get_subject_of_interest)
search_button.pack()

result_text = tk.StringVar()
result_label = tk.Label(root, textvariable=result_text)
result_label.pack()

# Start the Tkinter event loop
root.mainloop()

