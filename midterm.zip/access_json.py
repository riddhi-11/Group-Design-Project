import json

# Function to access user details from user_details.json
def access_user_details():
    try:
        with open("user_details.json", "r") as user_details_file:
            user_details = json.load(user_details_file)

        # Accessing user details
        for user_id, details in user_details.items():
            print(f"User ID: {user_id}")
            print(f"Name: {details['name']}")
            print(f"Pronouns: {details['pronouns']}")
            print(f"Country: {details['country']}")
            print(f"Interests: {details['interests']}")
            print(f"Looking for: {details['looking_for']}")
            print("\n")

    except FileNotFoundError:
        print("user_details.json not found.")

# Function to access login credentials from login_credentials.json
def access_login_credentials():
    try:
        with open("login_credentials.json", "r") as login_credentials_file:
            login_credentials = json.load(login_credentials_file)

        # Accessing login credentials
        for user_id, password in login_credentials.items():
            print(f"User ID: {user_id}")
            print(f"Password: {password}")
            print("\n")

    except FileNotFoundError:
        print("login_credentials.json not found.")

# Example usage:
# You can call these functions wherever you need to access the information from the JSON files.

# Access user details
access_user_details()

# Access login credentials
access_login_credentials()


