import tkinter as tk
import json   #
#giving blank matched profiles page

# Load existing user details and login credentials from JSON files
try:
    with open("user_details.json", "r") as user_details_file:
        user_details = json.load(user_details_file)
except FileNotFoundError:
    user_details = {}

try:
    with open("login_credentials.json", "r") as login_credentials_file:
        login_credentials = json.load(login_credentials_file)
except FileNotFoundError:
    login_credentials = {}

# Function to display users with the same interest
def display_users_with_same_interest(subject, entered_username):
    # Search for users with the same interest
    matching_users = {user: details for user, details in user_details.items()
                      if details.get("interests") == subject and user.split(" ")[0] != entered_username}

    return matching_users

# Function to display profiles
def display_profiles(profiles):
    global profiles_list
    global current_profile_index
    current_profile_index = -1
    profiles_list = list(profiles.items())
    display_next_profile()

# Function to display the next profile
def display_next_profile():
    global current_profile_index
    current_profile_index += 1
    if current_profile_index < len(profiles_list):
        user, details = profiles_list[current_profile_index]
        formatted_profile = (
            f"Name: {details['name']}\n"
            f"Pronouns: {details['pronouns']}\n"
            f"Bio: {details['bio']}\n"
            f"Interests: {details['interests']}\n"
            f"Email: {details['email']}"
        )
        result_text.set(formatted_profile)
    else:
        result_text.set("No more profiles to display.")

# Function to get the subject of interest
def get_subject_of_interest():
    subject = subject_entry.get().strip()
    entered_username = username_entry.get().strip()
    matching_users = display_users_with_same_interest(subject, entered_username)
    if matching_users:
        display_profiles(matching_users)
    else:
        result_text.set("No profiles found/invalid username entered")


# Function to accept a profile
# Initialize an empty dictionary to store accepted profiles for each user
accepted_profiles = {}
matched_profiles2 = {}


# Function to accept a profile
# Function to save accepted profiles to JSON file
def save_accepted_profiles_to_json(accepted_profiles):
    try:
        with open("accepted_profiles.json", "w") as accepted_profiles_file:
            json.dump(accepted_profiles, accepted_profiles_file, indent=4)
        print("Accepted profiles saved successfully.")
    except Exception as e:
        print(f"Error saving accepted profiles: {e}")

def load_accepted_profiles_from_json():
    try:
        with open("accepted_profiles.json", "r") as accepted_profiles_file:
            return json.load(accepted_profiles_file)
    except FileNotFoundError:
        return {}


# Function to accept a profile
def accept_profile():
    global profiles_list
    global accepted_profiles
    global matched_profiles2  # Changed from matched_profiles to matched_profiles2

    if current_profile_index >= 0:
        user, details = profiles_list[current_profile_index]
        accepting_username = username_entry.get().strip()  # Get the username of the user who is accepting

        # Update the accepted profiles list for the accepting user
        if accepting_username not in accepted_profiles:
            accepted_profiles[accepting_username] = []
        accepted_profiles[accepting_username].append(user)  # Append the accepted username to the list

        # Check if the accepted user has also accepted the accepting user
        if user in accepted_profiles and accepting_username in accepted_profiles[user]:
            # Update the matched profiles for both users
            if accepting_username not in matched_profiles2:  # Changed from matched_profiles to matched_profiles2
                matched_profiles2[accepting_username] = []  # Changed from matched_profiles to matched_profiles2
            if user not in matched_profiles2:  # Changed from matched_profiles to matched_profiles2
                matched_profiles2[user] = []  # Changed from matched_profiles to matched_profiles2
            matched_profiles2[accepting_username].append(user)  # Changed from matched_profiles to matched_profiles2
            matched_profiles2[user].append(accepting_username)  # Changed from matched_profiles to matched_profiles2

    # Save accepted profiles to JSON file
    save_accepted_profiles_to_json(accepted_profiles)

    display_next_profile()

    accepted_profiles = load_accepted_profiles_from_json()
# Function to deny a profile
def deny_profile():
    display_next_profile()

# Function to display matched profiles
def display_matched_profiles_window():
    # Create a new window for displaying matched profiles
    matched_profiles_window = tk.Toplevel(root)
    matched_profiles_window.title("Matched Profiles")

    # Get the username entered by the user
    entered_username = username_entry.get().strip()

    # Initialize a StringVar to display matched profiles
    matched_profiles_text = tk.StringVar()

    # Function to display matched profiles
    def display_matched_profiles(username):
        nonlocal matched_profiles_text
        if username in matched_profiles2:
            matched_users = matched_profiles2[username]
            matched_profiles_text.set("\n".join(matched_users))
        else:
            matched_profiles_text.set("No matched profiles found.")

    # Label to display matched profiles
    matched_profiles_label = tk.Label(matched_profiles_window, textvariable=matched_profiles_text, font=("Times New Roman", 14),
                                      bg="#FFC629", fg="black")
    matched_profiles_label.pack(padx=10, pady=10)

    # Display matched profiles for the entered username
    display_matched_profiles(entered_username)


# Create the main window
root = tk.Tk()
root.geometry("500x550")
root.title("STUMBLE 'Find Your Academic Match!'")
root.configure(bg="#FFC629")  # Light blue background

# Create and place the widgets
username_label = tk.Label(root, text="Your Username:", font=("Arial", 14), bg="#FFC629", fg="black")
username_label.pack(pady=(10, 0))

username_entry = tk.Entry(root)
username_entry.pack(pady=(0, 10))

subject_label = tk.Label(root, text="Subject of Interest:", font=("Arial", 14), bg="#FFC629", fg="black")
subject_label.pack(pady=(10, 0))

subject_entry = tk.Entry(root)
subject_entry.pack(pady=(0, 10))

search_button = tk.Button(root, text="Search", command=get_subject_of_interest, font=("Arial", 12))
search_button.pack()

result_text = tk.StringVar()
result_label = tk.Label(root, textvariable=result_text, font=("Times New Roman", 14), bg="#FFC629", fg="navy", justify="center")
result_label.pack(pady=(20, 10))

accept_button = tk.Button(root, text="Accept", command=accept_profile, bg="black", fg="green", font=("Arial", 12))
accept_button.place(relx=0.75, rely=0.9, anchor=tk.CENTER)

deny_button = tk.Button(root, text="Deny", command=deny_profile, bg="black", fg="red", font=("Arial", 12))
deny_button.place(relx=0.25, rely=0.9, anchor=tk.CENTER)

# Update the matched_profiles_button definition
matched_profiles_button = tk.Button(root, text="Matched Profiles", command=display_matched_profiles_window, bg="black", fg="blue", font=("Arial", 12))
matched_profiles_button.place(relx=0.5, rely=0.9, anchor=tk.CENTER)

# Start the Tkinter event loop
root.mainloop()
